                                 I PASSI DELLA REGINA

                          Un'avventura testuale di Davide Bucci

NOTA: la traduzione del gioco è attualmente in corso. Il gioco  è interamente 
tradotto in italiano, ma è ancora sotto beta testing. Ho comunque verificato
che lo si può giocare fino alla fine.

Per ogni consiglio o per segnalare errori, contattate davbucci@tiscali.it


Oggi è il 27 agosto 1904. Nove mesi fa, tu, Emilia Vittorini, hai raggiunto la
Spedizione Archeologica Italiana in Egitto, guidata da Ernesto Schiaparelli,
il direttore del museo Egizio di Torino. Adesso sei rientrata in Italia, a
Genova: il tuo traghetto a vapore è arrivato trasportando 25 casse in legno
che contengono il corredo della tomba della regina Nefertari Meritmut, un vero
tesoro! Le casse sono partite in treno in direzione di Torino. Mentre erano in
viaggio, sei stata invitata ad un sontuoso ricevimento organizzato da un ricco
collezionista d'arte, Eugenio Collovati conte di Raligotto. Non si può dire
che tu abbia apprezzato la serata...

Tuttavia, il ricevimento ha avuto luogo ieri sera: adesso devi prender il
treno per Torino ed assicurarti che il tesoro sia arrivato correttamente. Sarò
i tuoi occhi ed orecchie. Buona fortuna!^M^MDelle parole d'ordine verranno
date a dei momenti importanti del giuoco, sii pronto a prender nota. Scrivi
'aiuto' per aver istruzioni.

